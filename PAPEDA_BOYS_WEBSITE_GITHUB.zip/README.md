# PAPEDA BOYS Website

Website profil untuk proyek film animasi orisinal **PAPEDA BOYS: JALAN PANJANG MENUJU JANJI**.

## Isi folder
- `index.html` — struktur halaman website.
- `css/style.css` — desain, warna, dan tampilan responsif.
- `js/script.js` — menu navigasi untuk perangkat mobile dan tahun footer.

## Cara memasang di GitHub Pages
1. Buat repository GitHub bernama `papeda-boys`.
2. Unggah semua isi folder ini (bukan folder luarnya) ke repository.
3. Buka **Settings → Pages**.
4. Pada **Build and deployment**, pilih **Deploy from a branch**.
5. Pilih branch `main` dan folder `/ (root)`, lalu tekan **Save**.
6. Tunggu beberapa menit sampai GitHub menampilkan alamat website.

## Catatan sebelum dipublikasikan
- Ilustrasi Junior dibuat sebagai ilustrasi SVG sederhana di dalam HTML; rambutnya hitam dan keriting.
- Bagian galeri masih berupa panel konsep, bukan foto adegan film.
- Alamat `papeda.boys@example.com` pada tombol kontak adalah alamat contoh. Ganti dengan email resmi atau hapus tombol tersebut sebelum publikasi.
- Website memakai Google Fonts; jika internet tidak tersedia, browser akan memakai font pengganti.
